import { useState } from "react";
import BinanceLogo from "../components/BinanceLogo";
import ThemeToggle from "../components/ThemeToggle";
import CheckIcon from "../components/CheckIcon";

export default function Index() {
  const [email, setEmail] = useState("");
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log("Form submitted:", { email, agreedToTerms });
  };

  return (
    <div className="min-h-screen bg-binance-bg flex flex-col">
      {/* Header */}
      <header className="flex items-center justify-between bg-binance-bg h-16 px-4 border-b border-binance-border">
        <div className="flex items-center">
          <div className="flex items-center mr-2">
            <BinanceLogo className="w-[120px] h-6" />
          </div>
        </div>

        <div className="flex items-center">
          <div className="flex items-center cursor-pointer p-2">
            <ThemeToggle className="w-6 h-6" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-4 py-8 overflow-x-hidden overflow-y-auto">
        <div className="w-full max-w-md">
          <div className="space-y-6">
            {/* Title */}
            <div>
              <h1 className="text-[28px] font-semibold leading-9 text-binance-text-primary">
                Create Personal Account
              </h1>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Email/Phone Input */}
              <div className="space-y-1">
                <label className="block text-binance-text-primary font-medium text-sm leading-5">
                  Email/Phone number
                </label>
                <div className="relative">
                  <input
                    type="text"
                    name="username"
                    autoCapitalize="off"
                    spellCheck="false"
                    autoComplete="off"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="binance-input"
                    placeholder=""
                  />
                </div>
              </div>

              {/* Terms and Conditions Checkbox */}
              <div className="space-y-1">
                <label
                  htmlFor="registration-termAndCondition"
                  className="flex items-start cursor-pointer text-binance-text-secondary font-medium text-sm leading-5"
                >
                  <div className="flex items-center gap-2 mt-0.5">
                    <div
                      className={`binance-checkbox ${agreedToTerms ? "bg-binance-yellow border-binance-yellow" : ""}`}
                      onClick={() => setAgreedToTerms(!agreedToTerms)}
                    >
                      {agreedToTerms && (
                        <CheckIcon className="w-[14px] h-[14px] text-binance-bg" />
                      )}
                    </div>
                    <div className="flex-1 leading-5">
                      <span className="text-binance-text-secondary">
                        By creating an account, I agree to Binance's{" "}
                      </span>
                      <a
                        href="https://www.binance.com/en-GB/terms"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-binance-text-primary underline hover:no-underline"
                      >
                        Terms of Service
                      </a>
                      <span className="text-binance-text-secondary"> and </span>
                      <a
                        href="https://www.binance.com/en-GB/privacy"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-binance-text-primary underline hover:no-underline"
                      >
                        Privacy Notice
                      </a>
                      <span className="text-binance-text-secondary">.</span>
                    </div>
                  </div>
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="binance-button"
                disabled={!email || !agreedToTerms}
              >
                Next
              </button>
            </form>

            {/* Entity Account Link */}
            <div className="text-center space-y-1">
              <div className="text-binance-text-secondary font-medium text-sm leading-5">
                <span>Not looking for a personal account? </span>
                <button
                  type="button"
                  className="text-binance-yellow font-medium hover:underline cursor-pointer"
                >
                  Sign up for an entity account
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="flex items-center justify-center py-4 px-4 border-t border-binance-border">
        <div className="flex items-center space-x-4 text-xs leading-4 text-binance-text-muted">
          <div>Binance © 2025</div>
          <button
            type="button"
            className="cursor-pointer hover:text-binance-text-secondary"
          >
            Cookie Preferences
          </button>
        </div>
      </footer>
    </div>
  );
}
